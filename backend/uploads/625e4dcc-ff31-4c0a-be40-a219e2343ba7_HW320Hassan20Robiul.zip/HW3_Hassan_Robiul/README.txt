HW3 starter package (CAP 6776)

This folder is a working template that generates all required HW3 outputs.

Important:
- Replace data/corpus.csv with your own corpus (minimum 400 documents).
- Replace data/queries.csv with your own 10 queries.
- Build qrels by pooling the top-20 docs per query from the default BM25 run, then label each as 0, 1, or 2.

How to run:
1) Open hw3.ipynb
2) Run cells top to bottom
3) Check outputs folder for:
   - run_bm25_default.csv
   - run_bm25_tuned.csv
   - metrics_summary.csv
   - pr_curve_query_<query_id>.csv
   - pr_curve_query_<query_id>.png
   - error_analysis.txt

Notes:
- The sample data shipped here is only for testing the pipeline. It is not valid for submission because it is under 400 docs.
- Do not change CSV headers. Keep them exactly as in the assignment.

